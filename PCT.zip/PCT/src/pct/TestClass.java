package pct;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.swing.DefaultComboBoxModel;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class TestClass {
	
	
	SessionFactory factory = HibernateUtil.createSessionFactory();
	Session session = factory.getCurrentSession();
	Transaction transaction = session.beginTransaction();

	public static void main(String[] args) throws Exception
	{
		
		// TODO Auto-generated method stub
		 Connection conn=new Connection();
		 conn.setUsername("sydudais01");
		 conn.setPassword("My1job@mp302018");
		 conn.setUrl("jdbc:oracle:thin:@uorc372n.DEV.BSCAL.LOCAL:12521:FACN52A");
		 if(HibernateUtil.testConnection(conn)==true){
			System.out.println("Connected"); 
		 }
		//SessionFactory factory = HibernateUtil.createSessionFactory();
		//Session session = factory.getCurrentSession();
		//Transaction transaction = session.beginTransaction();
		//transaction.commit();
		
	}
	public String FirstName(String sbsbId)
	{
		Connection conn = PCTJFrame.getConnection();
		Query query1 = (Query) session.createSQLQuery("select SBSB_FIRST_NAME from FC_CMC_SBSB_SUBSC where SBSB_ID='"+sbsbId+"'");
		List result1 = query1.list();
		String fname=(String) result1.get(0);
		return fname;
	}
	public String LastName(String sbsbId)
	{
		Query query2 = (Query) session.createSQLQuery("select SBSB_LAST_NAME from FC_CMC_SBSB_SUBSC where SBSB_ID='"+sbsbId+"'");
		List result2 = query2.list();
		String lname=(String) result2.get(0);
		return lname;
	}
	public String GroupID(String sbsbId)
	{
		Query query3 = (Query) session.createSQLQuery("select GRGR_ID from FC_CMC_SBSB_SUBSC sbsb, FC_CMC_GRGR_GROUP grgr where sbsb.GRGR_CK=grgr.GRGR_CK and SBSB_ID='"+sbsbId+"'");
		List result3 = query3.list();
		String groupId=(String) result3.get(0);
	return groupId;
	}
	public String city(String sbsbId)
	{
		Query query4 = (Query) session.createSQLQuery("select  adr.SBAD_CITY from FC_CMC_SBSB_SUBSC sbsb,FC_CMC_SBAD_ADDR adr where sbsb.SBSB_CK = adr.SBSB_CK and sbsb.SBSB_ID='"+sbsbId+"'");
		List result4 = query4.list();
		String city=(String) result4.get(0);
		return city;
	}
	public java.util.Date dob(String sbsbId)
	{
		Query query5 = (Query) session.createSQLQuery("select   meme.MEME_BIRTH_DT from FC_CMC_SBSB_SUBSC sbsb, FC_CMC_MEME_MEMBER meme where sbsb.SBSB_CK= meme.SBSB_CK and meme.MEME_SFX ='00' and sbsb.SBSB_ID='"+sbsbId+"'");
		List result5 = query5.list();
		Timestamp dob=  (Timestamp) result5.get(0);
		java.util.Date date = (java.util.Date) new java.util.Date(dob.getTime());
		return date;
	}
	public String add(String sbsbId)
	{
		Query query6 = (Query) session.createSQLQuery("select  adr.SBAD_ADDR1 from FC_CMC_SBSB_SUBSC sbsb,FC_CMC_SBAD_ADDR adr where sbsb.SBSB_CK = adr.SBSB_CK and sbsb.SBSB_ID='"+sbsbId+"'");
		List result6 = query6.list();
		String add=(String) result6.get(0);
		return add;
	}
	
	public String zip(String sbsbId)
	{
		Query query7 = (Query) session.createSQLQuery("select  adr.SBAD_ZIP from FC_CMC_SBSB_SUBSC sbsb,FC_CMC_SBAD_ADDR adr where sbsb.SBSB_CK = adr.SBSB_CK and sbsb.SBSB_ID='"+sbsbId+"'");
		List result7 = query7.list();
		String zip=(String) result7.get(0);
		return zip;
	}
	
	public String state(String sbsbId)
	{
		Query query8 = (Query) session.createSQLQuery("select  adr.SBAD_STATE from FC_CMC_SBSB_SUBSC sbsb,FC_CMC_SBAD_ADDR adr where sbsb.SBSB_CK = adr.SBSB_CK and sbsb.SBSB_ID='"+sbsbId+"'");
		List result8 = query8.list();
		String state=(String) result8.get(0);
		return state;
	}
	
	public String gender(String sbsbId)
	{
		Query query5 = (Query) session.createSQLQuery("select   meme.MEME_SEX from FC_CMC_SBSB_SUBSC sbsb, FC_CMC_MEME_MEMBER meme where sbsb.SBSB_CK= meme.SBSB_CK and meme.MEME_SFX ='00' and sbsb.SBSB_ID='"+sbsbId+"'");
		List result5 = query5.list();
		String gender=  (String) result5.get(0);
		return gender;
	}
//	public String amount(String  object)
//	{
//		Query query9= (Query) session.createSQLQuery("select BLXP_PAID_AMT from FC_CMC_BLXP_EXT_PYMT where BLXP_CLCL_ID='"+object+"'");
//		List result9=query9.list();
//		String amount=(String) result9.get(0);
//		return amount;
//	}
	public BigDecimal amount(String  claimId)
	{
		Query query9= (Query) session.createSQLQuery("select BLXP_PAID_AMT from FC_CMC_BLXP_EXT_PYMT where BLXP_CLCL_ID='"+claimId+"'");
		List result9=query9.list();
		BigDecimal amount=(BigDecimal) result9.get(0);
		return amount;
	}
	
	public String check_nbr(String  claimId)
	{
		Query query10= (Query) session.createSQLQuery("select CHK_NBR_TXT from FACETS_CUSTOM.ARGUS_DBP_AFA_PMT_HIST WHERE CLM_ID='"+claimId+"'");
		List result10=query10.list();
		String chk=(String) result10.get(0);
		return chk;
	}
	public DefaultComboBoxModel getClaimIds(String sbsbId,String blxpid)
	{
		DefaultComboBoxModel model = new DefaultComboBoxModel();
		Query query6 = (Query) session.createSQLQuery("select BLXP_CLCL_ID from FC_CMC_BLXP_EXT_PYMT BLXP,FC_CMC_SBSB_SUBSC SBSB  where SBSB.SBSB_CK = BLXP.SBSB_CK  AND BLXP.BLXP_STS='"+blxpid+"' AND SBSB.SBSB_ID = '"+sbsbId+"' order by BLXP_PAID_DT desc");
		List list = query6.list();
		for (int i = 0; i < list.size(); i++) {
			model.addElement(list.get(i));
		}
		return model;
	}
	
	public String getSubGroup(String sbsbId)
	{
		Query query6 = (Query) session.createSQLQuery("SELECT DISTINCT SGSG.SGSG_ID FROM FACETS.CMC_SBSB_SUBSC SBSB,FACETS.CMC_SGSG_SUB_GROUP SGSG,FACETS.CMC_GRGR_GROUP GRGR WHERE GRGR.GRGR_CK = SBSB.GRGR_CK AND GRGR.GRGR_CK = SGSG.GRGR_CK  AND SBSB.SBSB_ID = '"+sbsbId+"'");
		List result6=query6.list();
		String subGrpId=(String) result6.get(0);
		return subGrpId;
	}
	
	public DefaultComboBoxModel getPlans(String sbsbId){
		DefaultComboBoxModel model = new DefaultComboBoxModel();
		Query query6 = (Query) session.createSQLQuery("SELECT DISTINCT ELIG.CSPI_ID FROM FC_CMC_SBEL_ELIG_ENT ELIG,FACETS.CMC_SBSB_SUBSC SBSB WHERE SBSB.SBSB_CK = ELIG.SBSB_CK AND SBSB.SBSB_ID = '"+sbsbId+"'");
		List list = query6.list();
		
		for (int i = 0; i < list.size(); i++) {
			model.addElement(list.get(i));
		}
		
		return model;
	}
	public void closeSession(){
		session.close();
	}
}
