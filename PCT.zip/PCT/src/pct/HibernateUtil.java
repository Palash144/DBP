package pct;

import java.util.Random;

import oracle.net.aso.r;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {
	
	
	public static SessionFactory createSessionFactory(){
		Connection conn = PCTJFrame.getConnection();
		Configuration configuration = new Configuration().configure();
		configuration.getProperties().setProperty("hibernate.connection.username", conn.getUsername());
		configuration.getProperties().setProperty("hibernate.connection.password", conn.getPassword());
		configuration.getProperties().setProperty("hibernate.connection.url", conn.getUrl());
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory factory = configuration.buildSessionFactory(serviceRegistry);
		return factory;
	}

	public static String generateClaimID()
	{
		Random r = new Random();
		Integer za = 100000 + r.nextInt(900000);
		String zas = za.toString();
		Integer zb = 100000 + r.nextInt(900000);
		String zbs = zb.toString();
		String claimID=zas+zbs;
		PCTDao dao = new PCTDao();
		while(dao.checkClaimID(claimID)==false)
		{
		claimID = HibernateUtil.generateClaimID();
		}
		return claimID;
		
		
	}
	public static String check1()
	{
		Random r = new Random();
		
		Integer zb = 100000000 + r.nextInt(900000000);
		String zbs = zb.toString();
		 System.out.println("random "+ zbs);
		
		return zbs;
		
	}
	
	public static boolean testConnection(Connection conn){
		boolean success = false;
		Configuration configuration = new Configuration().configure();
		configuration.getProperties().setProperty("hibernate.connection.username", conn.getUsername());
		configuration.getProperties().setProperty("hibernate.connection.password", conn.getPassword());
		configuration.getProperties().setProperty("hibernate.connection.url", conn.getUrl());
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory factory = configuration.buildSessionFactory(serviceRegistry);
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		success = session.isConnected();
		txn.commit();
		session.close();
		return success;
	}
	
	
}
