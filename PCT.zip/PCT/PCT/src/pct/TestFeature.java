package pct;

public class TestFeature {

	private static String con;

	public static void main(String[] args) {
		double amount1 =  4564.456;
		System.out.println(amount1);
		String amount  = String.valueOf(amount1);
		
		int length = amount.length();
		int pad = 11 - length;
		char ch = amount.charAt(length - 2);
		System.out.println(amount.indexOf('.')+" Index");
		
		if (ch == '.' && (amount.charAt(length-1)=='0') ) {
			System.out.println("first Condn");
			String padded = String.format("%0" + pad + "d", 0);
			String altered = amount.substring(0,amount.indexOf('.'));
			String altered2 = altered.concat(amount.substring(amount.indexOf('.')+1));
			con = padded+altered2;
			System.out.println(con);
		}else if((ch=='.') && (amount.charAt(length-1)!='0')) {
			
			String padded = String.format("%0" + pad + "d", 0);
			String altered = amount.substring(0,amount.indexOf('.'));
			String altered2 = altered.concat(amount.substring(amount.indexOf('.')+1));
			con = padded+altered2;
			
			System.out.println("Second Condn");
			System.out.println(con);
		}
		
		else if(amount.indexOf('.')<=(length-2)){
			System.out.println("Third Condn");
			String actualAmount = amount.substring(0,amount.indexOf('.'));
			int length1 = 10 - (actualAmount.length() + 1);
			char decimal = amount.charAt(amount.indexOf('.')+1);
			String padded = String.format("%0" + length1 + "d", 0);
			String altered2 = actualAmount+decimal;
			con= padded+altered2;
			System.out.println(con);
			
		}

	}

}
