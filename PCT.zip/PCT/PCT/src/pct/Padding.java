package pct;

public class Padding {
	public static void main(String[] args) {
//		String s="Lambhate";
//		// if name > length of position
//		if(s.length()>11) {
//		String sub=s.substring(0,Math.min(s.length(), 11));
//		System.out.println(sub);
//		}
//		// if name <= length of position
//		else
//		 System.out.println( String.format("%1$-" + 11 + "s", s)+ "^");
//	}

		String fname="Palash";
		int flen=fname.length();
		if (flen > 11) {
			fname = fname.substring(0, Math.min(fname.length(), 11));
			System.out.println(fname);
		} else {
			fname= String.format("%1$-" + 11 + "s", fname);
			System.out.println(fname+"@");

		}
} }