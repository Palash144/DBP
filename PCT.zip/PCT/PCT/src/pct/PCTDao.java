package pct;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class PCTDao {
	
	public boolean checkClaimID(String claimId){
	SessionFactory factory = HibernateUtil.createSessionFactory();
	Session session = factory.getCurrentSession();
	Transaction transaction = session.beginTransaction();
	
	Query query = (Query) session.createSQLQuery("Select * from FACETS_CUSTOM.AFA_RECONNET_TRNS_HIST where CLM_ID ='"+claimId+"'");
	List results = query.list();
	transaction.commit();
	if(results.isEmpty()){
		return true;
	}

	return false;
	
 }


}
