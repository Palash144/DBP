package dbp;

import java.util.Random;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class HibernateUtil {
	
	
	public static SessionFactory getSessionFactory() throws Exception {
        
        connectionDetails connectionDetail=ViewFrame.connectionDetail;
Configuration configuration = new Configuration().configure();
        configuration.getProperties().setProperty("hibernate.connection.username", connectionDetail.getUsername());
        configuration.getProperties().setProperty("hibernate.connection.password", connectionDetail.getPassword());
        configuration.getProperties().setProperty("hibernate.connection.url", connectionDetail.getUrl());

ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();

SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
return sessionFactory;
} 
	public static String generateClaimID() throws Exception
	{
		Random r = new Random();
		Integer za = 100000 + r.nextInt(900000);
		String zas = za.toString();
		Integer zb = 100000 + r.nextInt(900000);
		String zbs = zb.toString();
		String claimID=zas+zbs;
	    DBPDao dao = new DBPDao();
		while(dao.checkClaimID(claimID)==false)
		{
		claimID = HibernateUtil.generateClaimID();
		}
		return claimID;
	
	}
	
	public static int generateSubscriberID() throws Exception{
		Random r = new Random();
		int subID = 10000000 + r.nextInt(90000000);
		DBPDao dao = new DBPDao();
		while(dao.checkSubscriberID(subID)==false)
		{
			subID = HibernateUtil.generateSubscriberID();
		}
		return subID;
	}
	
}
